#!/bin/sh
# Copyright Ruediger Gad <r.c.g@gmx.de>
# This file is provided as-is and without any warranty.
# You can use it any way you like.
#
find . -name .svn -exec rm -rf {} \;
mv qtc_packaging/debian_harmattan debian
mv debian/sb_rules debian/rules
rm -rf qtc_packaging/
fakeroot dpkg-buildpackage -sa

