<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="en_US">
<context>
    <name>EmailComposerInterface</name>
    <message numerus="yes">
        <location filename="emailcomposer.cpp" line="171"/>
        <source>%n Attachment(s): %1KB</source>
        <translation type="unfinished">
            <numerusform>%n Attachment: %1KB</numerusform>
            <numerusform>%n Attachments: %1KB</numerusform>
        </translation>
    </message>
</context>
</TS>
