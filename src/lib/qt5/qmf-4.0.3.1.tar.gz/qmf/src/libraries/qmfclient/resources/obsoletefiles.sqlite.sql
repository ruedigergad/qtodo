CREATE TABLE obsoletefiles ( 
    mailfile VARCHAR);
