ALTER TABLE mailfolders ADD COLUMN serverundiscoveredcount INTEGER DEFAULT 0;
