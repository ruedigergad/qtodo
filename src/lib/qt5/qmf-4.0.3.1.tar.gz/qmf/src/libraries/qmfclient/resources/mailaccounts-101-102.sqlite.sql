ALTER TABLE mailaccounts ADD COLUMN signature VARCHAR;
