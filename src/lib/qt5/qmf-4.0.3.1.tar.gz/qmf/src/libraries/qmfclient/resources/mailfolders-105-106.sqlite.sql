DELETE FROM mailfolders WHERE id = 1;
