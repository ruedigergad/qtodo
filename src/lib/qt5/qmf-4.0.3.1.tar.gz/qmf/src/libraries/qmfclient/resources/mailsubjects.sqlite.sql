CREATE TABLE mailsubjects (
    id INTEGER PRIMARY KEY NOT NULL,
    basesubject VARCHAR UNIQUE);
