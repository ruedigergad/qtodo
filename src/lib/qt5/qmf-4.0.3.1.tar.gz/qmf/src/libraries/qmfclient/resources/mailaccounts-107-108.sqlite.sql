ALTER TABLE mailaccounts ADD COLUMN iconpath VARCHAR;
