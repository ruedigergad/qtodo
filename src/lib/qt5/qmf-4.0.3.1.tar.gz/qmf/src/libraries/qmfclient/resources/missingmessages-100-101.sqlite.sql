ALTER TABLE missingmessages ADD COLUMN level INTEGER;
