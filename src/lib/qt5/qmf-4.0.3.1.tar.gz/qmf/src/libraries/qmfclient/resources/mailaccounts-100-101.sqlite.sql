ALTER TABLE mailaccounts ADD COLUMN status INTEGER;
