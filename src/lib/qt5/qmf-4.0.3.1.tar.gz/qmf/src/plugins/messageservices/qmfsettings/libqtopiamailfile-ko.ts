<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0">
<context>
    <name>QMailMessageService</name>
    <message>
        <location filename="service.cpp" line="47"/>
        <source>Mailfile</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Qtopiamailfile</name>
    <message>
        <location filename="storagelocations.cpp" line="25"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QtopiamailfileSettings</name>
    <message>
        <location filename="settings.ui" line="20"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="settings.ui" line="32"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
