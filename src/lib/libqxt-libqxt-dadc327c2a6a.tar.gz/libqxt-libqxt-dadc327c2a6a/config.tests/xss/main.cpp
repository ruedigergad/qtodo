#include <X11/extensions/scrnsaver.h>

int main()
{
    XScreenSaverAllocInfo();
    return 0;
}
