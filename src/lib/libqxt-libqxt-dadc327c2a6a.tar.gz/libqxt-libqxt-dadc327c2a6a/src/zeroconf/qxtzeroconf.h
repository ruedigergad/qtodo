#ifndef QXTSERVICEBROWSER_H
#define QXTSERVICEBROWSER_H

#include "qxtdiscoverableservice.h"
#include "qxtdiscoverableservicename.h"
#include "qxtservicebrowser.h"

#endif // QXTSERVICEBROWSER_H
