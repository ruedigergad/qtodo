#include <iostream>
using namespace std;

int main(int argc, char** argv) {
    cout << "Content-type: text/html\r\n";
    cout << "\r\n";
    cout << "<html><body>I've got lots of content!</body></html>";
}
